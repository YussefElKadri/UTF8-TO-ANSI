﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace UTF8_To_ANSI
{
	internal class ConverteUSTD
	{

		public string LeituraConverteUSTD(string pasta)
		{
			string[] listaUSTD = Directory.GetFiles(pasta,"*.TXT",SearchOption.AllDirectories);
			string USTDtemp = Path.GetTempFileName();

			foreach (var item in listaUSTD)
			{
				string leituraUSTD = File.ReadAllText(item);
				
				StreamWriter escritaNOVOUSTD = new StreamWriter(USTDtemp, true, Encoding.GetEncoding("iso-8859-1"));
				{
					for (int i = 0; i < leituraUSTD.Length; i++)
					{
						escritaNOVOUSTD.Write(leituraUSTD[i]);
					}
				}
				escritaNOVOUSTD.Dispose();
				escritaNOVOUSTD.Close();

				File.Delete(item);
				File.Copy(USTDtemp, item.ToString().Replace("TXT" , "CSV")); ;
			}
			return pasta;
		}


	}
}
